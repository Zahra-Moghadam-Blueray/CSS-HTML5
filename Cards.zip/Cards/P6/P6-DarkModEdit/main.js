let card = document.getElementById("cardMode");
let icon = document.querySelector(".theme-changer i");

function themeChange() {
   card.classList.toggle("dark");
   icon.classList.toggle("fa-moon");
   icon.classList.toggle("fa-sun");
}
